/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/abtin/Desktop/ISEprojects/CO_project3/increment_decremnet_counter.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_2507238156_503743352(char *, unsigned char , unsigned char );
unsigned char ieee_p_2592010699_sub_2545490612_503743352(char *, unsigned char , unsigned char );


static void work_a_1005851574_0632001823_p_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    unsigned char t11;
    unsigned char t12;
    unsigned char t13;
    unsigned char t14;
    int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned char t19;
    unsigned char t20;
    int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned char t25;
    unsigned char t26;
    char *t27;
    int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    char *t35;
    unsigned char t36;
    char *t37;
    int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned char t42;
    unsigned char t43;
    unsigned char t44;
    char *t45;
    char *t46;
    int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned char t51;
    unsigned char t52;
    unsigned char t53;
    char *t54;
    char *t55;
    int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned char t60;
    unsigned char t61;
    unsigned char t62;
    unsigned char t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;

LAB0:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = (t3 == (unsigned char)3);
    if (t4 != 0)
        goto LAB2;

LAB4:    t1 = (t0 + 1152U);
    t4 = xsi_signal_has_event(t1);
    if (t4 == 1)
        goto LAB7;

LAB8:    t3 = (unsigned char)0;

LAB9:    if (t3 != 0)
        goto LAB5;

LAB6:
LAB3:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t1 = (t0 + 4416);
    t5 = (t1 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    memcpy(t8, t2, 4U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 3952);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(32, ng0);
    t1 = (t0 + 7431);
    t6 = (t0 + 4032);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 4U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(33, ng0);
    t1 = (t0 + 7435);
    t5 = (t0 + 4096);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 4U);
    xsi_driver_first_trans_fast(t5);
    goto LAB3;

LAB5:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 1352U);
    t6 = *((char **)t2);
    t13 = *((unsigned char *)t6);
    t14 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t13);
    t2 = (t0 + 1672U);
    t7 = *((char **)t2);
    t15 = (2 - 3);
    t16 = (t15 * -1);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t2 = (t7 + t18);
    t19 = *((unsigned char *)t2);
    t20 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t14, t19);
    t8 = (t0 + 1672U);
    t9 = *((char **)t8);
    t21 = (1 - 3);
    t22 = (t21 * -1);
    t23 = (1U * t22);
    t24 = (0 + t23);
    t8 = (t9 + t24);
    t25 = *((unsigned char *)t8);
    t26 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t20, t25);
    t10 = (t0 + 1672U);
    t27 = *((char **)t10);
    t28 = (0 - 3);
    t29 = (t28 * -1);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t10 = (t27 + t31);
    t32 = *((unsigned char *)t10);
    t33 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t26, t32);
    t34 = (t0 + 1352U);
    t35 = *((char **)t34);
    t36 = *((unsigned char *)t35);
    t34 = (t0 + 1672U);
    t37 = *((char **)t34);
    t38 = (2 - 3);
    t39 = (t38 * -1);
    t40 = (1U * t39);
    t41 = (0 + t40);
    t34 = (t37 + t41);
    t42 = *((unsigned char *)t34);
    t43 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t42);
    t44 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t36, t43);
    t45 = (t0 + 1672U);
    t46 = *((char **)t45);
    t47 = (1 - 3);
    t48 = (t47 * -1);
    t49 = (1U * t48);
    t50 = (0 + t49);
    t45 = (t46 + t50);
    t51 = *((unsigned char *)t45);
    t52 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t51);
    t53 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t44, t52);
    t54 = (t0 + 1672U);
    t55 = *((char **)t54);
    t56 = (0 - 3);
    t57 = (t56 * -1);
    t58 = (1U * t57);
    t59 = (0 + t58);
    t54 = (t55 + t59);
    t60 = *((unsigned char *)t54);
    t61 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t60);
    t62 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t53, t61);
    t63 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t33, t62);
    t64 = (t0 + 4160);
    t65 = (t64 + 56U);
    t66 = *((char **)t65);
    t67 = (t66 + 56U);
    t68 = *((char **)t67);
    *((unsigned char *)t68) = t63;
    xsi_driver_first_trans_fast(t64);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 1672U);
    t5 = *((char **)t1);
    t15 = (1 - 3);
    t16 = (t15 * -1);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t1 = (t5 + t18);
    t11 = *((unsigned char *)t1);
    t12 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t4, t11);
    t6 = (t0 + 1672U);
    t7 = *((char **)t6);
    t21 = (0 - 3);
    t22 = (t21 * -1);
    t23 = (1U * t22);
    t24 = (0 + t23);
    t6 = (t7 + t24);
    t13 = *((unsigned char *)t6);
    t14 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t12, t13);
    t8 = (t0 + 1352U);
    t9 = *((char **)t8);
    t19 = *((unsigned char *)t9);
    t8 = (t0 + 1672U);
    t10 = *((char **)t8);
    t28 = (1 - 3);
    t29 = (t28 * -1);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t8 = (t10 + t31);
    t20 = *((unsigned char *)t8);
    t25 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t20);
    t26 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t19, t25);
    t27 = (t0 + 1672U);
    t34 = *((char **)t27);
    t38 = (0 - 3);
    t39 = (t38 * -1);
    t40 = (1U * t39);
    t41 = (0 + t40);
    t27 = (t34 + t41);
    t32 = *((unsigned char *)t27);
    t33 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t32);
    t36 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t26, t33);
    t42 = ieee_p_2592010699_sub_2545490612_503743352(IEEE_P_2592010699, t14, t36);
    t35 = (t0 + 4224);
    t37 = (t35 + 56U);
    t45 = *((char **)t37);
    t46 = (t45 + 56U);
    t54 = *((char **)t46);
    *((unsigned char *)t54) = t42;
    xsi_driver_first_trans_fast(t35);
    xsi_set_current_line(37, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 1672U);
    t5 = *((char **)t1);
    t15 = (0 - 3);
    t16 = (t15 * -1);
    t17 = (1U * t16);
    t18 = (0 + t17);
    t1 = (t5 + t18);
    t4 = *((unsigned char *)t1);
    t11 = ieee_p_2592010699_sub_2507238156_503743352(IEEE_P_2592010699, t3, t4);
    t6 = (t0 + 4288);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    *((unsigned char *)t10) = t11;
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(38, ng0);
    t1 = (t0 + 4352);
    t2 = (t1 + 56U);
    t5 = *((char **)t2);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB3;

LAB7:    t2 = (t0 + 1192U);
    t5 = *((char **)t2);
    t11 = *((unsigned char *)t5);
    t12 = (t11 == (unsigned char)3);
    t3 = t12;
    goto LAB9;

}


extern void work_a_1005851574_0632001823_init()
{
	static char *pe[] = {(void *)work_a_1005851574_0632001823_p_0};
	xsi_register_didat("work_a_1005851574_0632001823", "isim/increment_decrement_counter_tb_isim_beh.exe.sim/work/a_1005851574_0632001823.didat");
	xsi_register_executes(pe);
}
